﻿#ifndef TEXT_H
#define TEXT_H

#include<QString>
#include"string"
#include<QList>
#include"iostream"
#include<QDate>
#include"l.h"
using namespace std;
#endif // TEXT_H

