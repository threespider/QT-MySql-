﻿#ifndef SQL
#define SQL

#include"QVariant"
#include"QVariantList"
#include"QLinkedList"
#include"QList"
#include"QSqlRecord"
#include<QtSql/QSqlDatabase>
#include<QtSql/QSqlTableModel>
#include<QtSql/QSqlQuery>
#include<QStringList>
#include<QMap>
#include<QString>
#include"l.h"
#endif // SQL

