# POPManageSystem
使用Qt开发的一个简单的超市收银管理系统


## 编译使用

编译完成后，需要拷贝 `file`目录下的数据库 `POP.db`文件到可执行程序目录下


登录

![登录界面](./screen/login.png)

主界面

![主界面](./screen/mainFrame.png)

![主界面](./screen/mainFrame2.png)


会员管理

![主界面](./screen/memberMgr.png)

## 总结

关于详细介绍以及使用过程，可以关注微信公众号： devstone， 获取查看


![主界面](./image/logo.png)
